export default [
    {
        "input": "Madalina",
        "output": "F"
    },
    {
        "input": "Ana",
        "output": "F"
    },
    {
        "input": "Cornelia",
        "output": "F"
    },
    {
        "input": "Costel",
        "output": "M"
    },
    {
        "input": "Tanta",
        "output": "F"
    },
    {
        "input": "Razvan",
        "output": "M"
    },
    {
        "input": "Anastasia",
        "output": "F"
    },
    {
        "input": "Radu",
        "output": "M"
    },
    {
        "input": "Medeea",
        "output": "F"
    },
    {
        "input": "Mihail",
        "output": "M"
    },
    {
        "input": "Andreea",
        "output": "F"
    },
    {
        "input": "Catalin",
        "output": "M"
    },
    {
        "input": "Pulica",
        "output": "M"
    },
    {
        "input": "Karina",
        "output": "F"
    },
    {
        "input": "Alexandru",
        "output": "M"
    },
    {
        "input": "Andrei",
        "output": "M"
    },
    {
        "input": "Ianis",
        "output": "M"
    },
    {
        "input": "Denis-Stefan",
        "output": "M"
    },
    {
        "input": "Christian",
        "output": "F"
    },
    {
        "input": "Daria",
        "output": "F"
    },
    {
        "input": "Penisache",
        "output": "M"
    },
    {
        "input": "Denis",
        "output": "M"
    },
    {
        "input": "Eduard",
        "output": "M"
    },
    {
        "input": "Drago",
        "output": "M"
    },
    {
        "input": "Lucas",
        "output": "M"
    },
    {
        "input": "Matias",
        "output": "M"
    },
    {
        "input": "Cristi",
        "output": "M"
    },
    {
        "input": "Laur",
        "output": "M"
    },
    {
        "input": "Cezar",
        "output": "M"
    },
    {
        "input": "Dodo",
        "output": "M"
    },
    {
        "input": "Sofia",
        "output": "F"
    },
    {
        "input": "Narcis",
        "output": "M"
    },
    {
        "input": "Andrada",
        "output": "F"
    },
    {
        "input": "Ioana",
        "output": "F"
    },
    {
        "input": "Roxana",
        "output": "F"
    },
    {
        "input": "Clin",
        "output": "M"
    },
    {
        "input": "Calin",
        "output": "M"
    },
    {
        "input": "Rebecca",
        "output": "F"
    },
    {
        "input": "Cornel",
        "output": "M"
    },
    {
        "input": "Nicoleta",
        "output": "F"
    },
    {
        "input": "Maria",
        "output": "F"
    },
    {
        "input": "Damian",
        "output": "M"
    },
    {
        "input": "Antonia",
        "output": "F"
    },
    {
        "input": "Vlad",
        "output": "M"
    },
    {
        "input": "Eliza",
        "output": "F"
    },
    {
        "input": "Sophia-Maria",
        "output": "F"
    },
    {
        "input": "Teodorz",
        "output": "F"
    },
    {
        "input": "Irina",
        "output": "F"
    },
    {
        "input": "Ciprian",
        "output": "M"
    },
    {
        "input": "Stefan",
        "output": "M"
    },
    {
        "input": "Marcu",
        "output": "M"
    },
    {
        "input": "Luca",
        "output": "M"
    },
    {
        "input": "Rare",
        "output": "M"
    },
    {
        "input": "Iarina",
        "output": "F"
    },
    {
        "input": "Sonia",
        "output": "F"
    },
    {
        "input": "Mdlina",
        "output": "F"
    },
    {
        "input": "MÄƒdÄƒlina",
        "output": "F"
    },
    {
        "input": "Georgeta",
        "output": "F"
    },
    {
        "input": "Cristina",
        "output": "F"
    },
    {
        "input": "Darius",
        "output": "M"
    },
    {
        "input": "Roberta",
        "output": "F"
    },
    {
        "input": "Larisa",
        "output": "F"
    },
    {
        "input": "IRIS",
        "output": "F"
    },
    {
        "input": "Marian",
        "output": "M"
    },
    {
        "input": "Marius",
        "output": "M"
    },
    {
        "input": "Vanesa",
        "output": "F"
    },
    {
        "input": "Rares",
        "output": "M"
    },
    {
        "input": "Iulia",
        "output": "F"
    },
    {
        "input": "Casian-Anatolie",
        "output": "M"
    },
    {
        "input": "Patricia",
        "output": "F"
    },
    {
        "input": "Robert",
        "output": "F"
    },
    {
        "input": "Matei",
        "output": "M"
    },
    {
        "input": "Christian",
        "output": "M"
    },
    {
        "input": "Alessia",
        "output": "F"
    },
    {
        "input": "Adelina",
        "output": "F"
    },
    {
        "input": "Aida-Anastasia",
        "output": "F"
    },
    {
        "input": "Rodica",
        "output": "F"
    },
    {
        "input": "Theodor",
        "output": "M"
    },
    {
        "input": "Ayan",
        "output": "M"
    },
    {
        "input": "Teodor-Cristian",
        "output": "M"
    },
    {
        "input": "Eleonora",
        "output": "F"
    },
    {
        "input": "Iuliana",
        "output": "F"
    },
    {
        "input": "Camelia",
        "output": "F"
    },
    {
        "input": "Daniel",
        "output": "M"
    },
    {
        "input": "Flavia",
        "output": "F"
    },
    {
        "input": "Mario",
        "output": "M"
    },
    {
        "input": "David",
        "output": "M"
    },
    {
        "input": "SARA",
        "output": "F"
    },
    {
        "input": "Livia",
        "output": "M"
    },
    {
        "input": "Mada",
        "output": "F"
    },
    {
        "input": "Nectarie",
        "output": "M"
    },
    {
        "input": "Cosmin",
        "output": "M"
    },
    {
        "input": "Izabela",
        "output": "F"
    },
    {
        "input": "Tudor",
        "output": "M"
    },
    {
        "input": "Diana",
        "output": "F"
    },
    {
        "input": "Eric",
        "output": "M"
    },
    {
        "input": "Patric",
        "output": "M"
    },
    {
        "input": "Andrea",
        "output": "F"
    },
    {
        "input": "Gabriel",
        "output": "M"
    },
    {
        "input": "Kevin",
        "output": "M"
    },
    {
        "input": "Ziana",
        "output": "F"
    },
    {
        "input": "Elena",
        "output": "F"
    },
    {
        "input": "Anastasia-Nicoleta",
        "output": "F"
    },
    {
        "input": "Nadia",
        "output": "F"
    },
    {
        "input": "Maya",
        "output": "F"
    },
    {
        "input": "Andi",
        "output": "M"
    },
    {
        "input": "MÃ¡rk",
        "output": "M"
    },
    {
        "input": "Nicholas",
        "output": "M"
    },
    {
        "input": "Gaby",
        "output": "M"
    },
    {
        "input": "Stef",
        "output": "F"
    },
    {
        "input": "Catalina",
        "output": "F"
    },
    {
        "input": "Patrick",
        "output": "M"
    },
    {
        "input": "Victor",
        "output": "M"
    },
    {
        "input": "Sebastian",
        "output": "M"
    },
    {
        "input": "Mara",
        "output": "F"
    },
    {
        "input": "Iustin",
        "output": "M"
    },
    {
        "input": "Luis",
        "output": "M"
    },
    {
        "input": "RareÈ™",
        "output": "M"
    },
    {
        "input": "Rebeca",
        "output": "F"
    },
    {
        "input": "Carla",
        "output": "F"
    },
    {
        "input": "Raul",
        "output": "M"
    },
    {
        "input": "Matilda",
        "output": "F"
    },
    {
        "input": "Elisabetta",
        "output": "F"
    },
    {
        "input": "Zsofia",
        "output": "F"
    },
    {
        "input": "Beatrice",
        "output": "F"
    },
    {
        "input": "Arian",
        "output": "M"
    },
    {
        "input": "Ema",
        "output": "F"
    },
    {
        "input": "Rucsandra",
        "output": "F"
    },
    {
        "input": "Stefania",
        "output": "F"
    },
    {
        "input": "Oana-Sofia",
        "output": "F"
    },
    {
        "input": "Lacramioara",
        "output": "F"
    },
    {
        "input": "DÄƒnel",
        "output": "M"
    },
    {
        "input": "Iosif",
        "output": "M"
    },
    {
        "input": "Teofan",
        "output": "M"
    },
    {
        "input": "Costin",
        "output": "M"
    },
    {
        "input": "Filip",
        "output": "M"
    },
    {
        "input": "Ana-Maria",
        "output": "F"
    },
    {
        "input": "Ioan",
        "output": "M"
    },
    {
        "input": "Maia",
        "output": "F"
    },
    {
        "input": "Adela",
        "output": "F"
    },
    {
        "input": "Mihaela",
        "output": "F"
    },
    {
        "input": "IACOB",
        "output": "M"
    },
    {
        "input": "Victoria",
        "output": "F"
    },
    {
        "input": "Luca-Andrei",
        "output": "M"
    },
    {
        "input": "Aryana",
        "output": "F"
    },
    {
        "input": "Fabian",
        "output": "M"
    },
    {
        "input": "Antonia-Mihaela",
        "output": "F"
    },
    {
        "input": "Matei-Gabriel",
        "output": "M"
    },
    {
        "input": "Claudiu",
        "output": "M"
    },
    {
        "input": "Sarah",
        "output": "F"
    },
    {
        "input": "Luca-Vladimir",
        "output": "M"
    },
    {
        "input": "Melisa",
        "output": "F"
    },
    {
        "input": "Carla-Siena",
        "output": "F"
    },
    {
        "input": "Olivia",
        "output": "F"
    },
    {
        "input": "Rafael",
        "output": "M"
    },
    {
        "input": "Nikolas",
        "output": "M"
    },
    {
        "input": "Ioana-Darina",
        "output": "F"
    },
    {
        "input": "ILINCA",
        "output": "F"
    },
    {
        "input": "Erika",
        "output": "F"
    },
    {
        "input": "Abigail",
        "output": "F"
    },
    {
        "input": "Paul",
        "output": "M"
    },
    {
        "input": "Aylin",
        "output": "F"
    },
    {
        "input": "Anais",
        "output": "F"
    },
    {
        "input": "Dragos",
        "output": "M"
    },
    {
        "input": "Cristiana",
        "output": "F"
    },
    {
        "input": "Lorena",
        "output": "F"
    },
    {
        "input": "Bianca",
        "output": "F"
    },
    {
        "input": "Iosua",
        "output": "M"
    },
    {
        "input": "Horia",
        "output": "M"
    },
    {
        "input": "Lucian",
        "output": "M"
    },
    {
        "input": "Zian",
        "output": "M"
    },
    {
        "input": "Laurentiu",
        "output": "M"
    },
    {
        "input": "Sebi",
        "output": "M"
    },
    {
        "input": "Denisa",
        "output": "F"
    },
    {
        "input": "DOMINIC",
        "output": "M"
    },
    {
        "input": "Amelie",
        "output": "F"
    },
    {
        "input": "Bogdan",
        "output": "M"
    },
    {
        "input": "Emma",
        "output": "F"
    },
    {
        "input": "Denis.Ionut",
        "output": "M"
    },
    {
        "input": "Teodor",
        "output": "M"
    },
    {
        "input": "Nicolas",
        "output": "M"
    },
    {
        "input": "Cataleya",
        "output": "F"
    },
    {
        "input": "Raisa",
        "output": "F"
    },
    {
        "input": "Eva-Teodora",
        "output": "F"
    },
    {
        "input": "Anyonia",
        "output": "F"
    },
    {
        "input": "Karla",
        "output": "F"
    },
    {
        "input": "Natalia",
        "output": "F"
    },
    {
        "input": "MayaAlessia",
        "output": "F"
    },
    {
        "input": "PREGATITOARE",
        "output": "F"
    },
    {
        "input": "Casian",
        "output": "M"
    },
    {
        "input": "Alexia",
        "output": "F"
    },
    {
        "input": "RÄƒzvan",
        "output": "M"
    },
    {
        "input": "Vladimir",
        "output": "M"
    },
    {
        "input": "Cazimir",
        "output": "M"
    },
    {
        "input": "Teodora",
        "output": "F"
    },
    {
        "input": "Raluca",
        "output": "F"
    },
    {
        "input": "Karim",
        "output": "M"
    },
    {
        "input": "Eva",
        "output": "F"
    },
    {
        "input": "Elias",
        "output": "M"
    },
    {
        "input": "Daniela",
        "output": "F"
    },
    {
        "input": "VlÄƒduÈ›",
        "output": "M"
    },
    {
        "input": "Thea",
        "output": "F"
    },
    {
        "input": "Armin",
        "output": "M"
    },
    {
        "input": "INGRID",
        "output": "F"
    },
    {
        "input": "Matei-Marian",
        "output": "M"
    },
    {
        "input": "Alessia-ioana",
        "output": "F"
    },
    {
        "input": "Albert",
        "output": "M"
    },
    {
        "input": "Celine",
        "output": "F"
    },
    {
        "input": "Zenaida",
        "output": "F"
    },
    {
        "input": "Dariana",
        "output": "F"
    },
    {
        "input": "Francesca",
        "output": "F"
    },
    {
        "input": "Mattias",
        "output": "M"
    },
    {
        "input": "Evelyn",
        "output": "F"
    },
    {
        "input": "Catarina",
        "output": "F"
    },
    {
        "input": "Erica",
        "output": "F"
    },
    {
        "input": "Sergiu",
        "output": "M"
    },
    {
        "input": "Simona",
        "output": "M"
    },
    {
        "input": "Simona",
        "output": "F"
    },
    {
        "input": "Ada",
        "output": "F"
    },
    {
        "input": "DominicAndrei",
        "output": "M"
    },
    {
        "input": "Amelia",
        "output": "F"
    },
    {
        "input": "Amalia",
        "output": "F"
    },
    {
        "input": "Flavius",
        "output": "M"
    },
    {
        "input": "Livia",
        "output": "F"
    },
    {
        "input": "Andra",
        "output": "F"
    },
    {
        "input": "George",
        "output": "M"
    },
    {
        "input": "Mihai",
        "output": "M"
    },
    {
        "input": "Giulia-Maria",
        "output": "F"
    },
    {
        "input": "Adrian",
        "output": "M"
    },
    {
        "input": "DAVID-NICOLAS",
        "output": "M"
    },
    {
        "input": "Tania",
        "output": "F"
    },
    {
        "input": "Maximilian",
        "output": "M"
    },
    {
        "input": "SOPHIA",
        "output": "F"
    },
    {
        "input": "Andy",
        "output": "M"
    },
    {
        "input": "Robert",
        "output": "M"
    },
    {
        "input": "Ethen",
        "output": "M"
    },
    {
        "input": "È˜tefania",
        "output": "F"
    },
    {
        "input": "Sofia",
        "output": "M"
    },
    {
        "input": "Ava",
        "output": "F"
    },
    {
        "input": "LÄƒcrÄƒmioara",
        "output": "F"
    },
    {
        "input": "È˜tefan",
        "output": "M"
    },
    {
        "input": "RaisaDaiana",
        "output": "F"
    },
    {
        "input": "Traian",
        "output": "M"
    },
    {
        "input": "Luna",
        "output": "F"
    },
    {
        "input": "Veronica",
        "output": "F"
    },
    {
        "input": "Mathias",
        "output": "M"
    },
    {
        "input": "Alex",
        "output": "M"
    },
    {
        "input": "Ined",
        "output": "F"
    },
    {
        "input": "Ines",
        "output": "F"
    },
    {
        "input": "Naomi",
        "output": "F"
    },
    {
        "input": "Ariana",
        "output": "F"
    },
    {
        "input": "Adelin",
        "output": "M"
    },
    {
        "input": "Ruxandra",
        "output": "F"
    },
    {
        "input": "Mia",
        "output": "F"
    },
    {
        "input": "Edi",
        "output": "M"
    },
    {
        "input": "Maria-Ioana",
        "output": "F"
    },
    {
        "input": "Bogdanel",
        "output": "M"
    },
    {
        "input": "Alexandra",
        "output": "F"
    },
    {
        "input": "Ecaterina",
        "output": "F"
    },
    {
        "input": "Denosa",
        "output": "F"
    },
    {
        "input": "Iasmina",
        "output": "F"
    },
    {
        "input": "Lara",
        "output": "F"
    },
    {
        "input": "Miriam",
        "output": "F"
    },
    {
        "input": "Sofi",
        "output": "F"
    },
    {
        "input": "Antonio",
        "output": "M"
    },
    {
        "input": "Matteo",
        "output": "M"
    },
    {
        "input": "Eric-Daniel",
        "output": "M"
    },
    {
        "input": "Antonio-Cristian",
        "output": "M"
    },
    {
        "input": "Alexandru-Sebastian",
        "output": "M"
    },
    {
        "input": "Erik",
        "output": "M"
    },
    {
        "input": "Rachel",
        "output": "F"
    },
    {
        "input": "Felix",
        "output": "M"
    },
    {
        "input": "Yasmin",
        "output": "F"
    },
    {
        "input": "Desiree",
        "output": "F"
    },
    {
        "input": "Drqgos",
        "output": "M"
    },
    {
        "input": "Annabelle",
        "output": "F"
    },
    {
        "input": "Gabriela",
        "output": "F"
    },
    {
        "input": "Ahmad",
        "output": "M"
    },
    {
        "input": "Hanan",
        "output": "F"
    },
    {
        "input": "Mateo",
        "output": "M"
    },
    {
        "input": "Carol",
        "output": "M"
    },
    {
        "input": "Matthias",
        "output": "M"
    },
    {
        "input": "Anna",
        "output": "F"
    },
    {
        "input": "Luca-Gabriel",
        "output": "M"
    },
    {
        "input": "Simina",
        "output": "F"
    },
    {
        "input": "Georgiana",
        "output": "F"
    },
    {
        "input": "Ruth",
        "output": "F"
    },
    {
        "input": "Ayana",
        "output": "F"
    },
    {
        "input": "Louis",
        "output": "M"
    },
    {
        "input": "Melissa",
        "output": "F"
    },
    {
        "input": "Elena-Iulia",
        "output": "F"
    },
    {
        "input": "David-Gabriel",
        "output": "M"
    },
    {
        "input": "Anelisse",
        "output": "F"
    },
    {
        "input": "Marco",
        "output": "M"
    },
    {
        "input": "Iani",
        "output": "M"
    },
    {
        "input": "Tudor!",
        "output": "M"
    },
    {
        "input": "Rayan",
        "output": "M"
    },
    {
        "input": "Marta",
        "output": "F"
    },
    {
        "input": "Arthur",
        "output": "M"
    },
    {
        "input": "Alex-Gabriel",
        "output": "M"
    },
    {
        "input": "Vlad-È˜tefan",
        "output": "M"
    },
    {
        "input": "Cristian",
        "output": "M"
    },
    {
        "input": "Miruna",
        "output": "F"
    },
    {
        "input": "Patrick-Ioan",
        "output": "M"
    },
    {
        "input": "Emilia",
        "output": "F"
    },
    {
        "input": "Erick-Gabriel",
        "output": "M"
    },
    {
        "input": "Milena-Eva",
        "output": "F"
    },
    {
        "input": "Nicol",
        "output": "F"
    },
    {
        "input": "BEBELINDA",
        "output": "F"
    },
    {
        "input": "Eveline",
        "output": "F"
    },
    {
        "input": "Petru",
        "output": "M"
    },
    {
        "input": "Denis-Iulian",
        "output": "M"
    },
    {
        "input": "Annabel",
        "output": "F"
    },
    {
        "input": "Teo",
        "output": "F"
    },
    {
        "input": "Melania",
        "output": "F"
    },
    {
        "input": "NataliaKatalina",
        "output": "F"
    },
    {
        "input": "JÃ¡zmin",
        "output": "F"
    },
    {
        "input": "Amira",
        "output": "F"
    },
    {
        "input": "Charlotte",
        "output": "F"
    },
    {
        "input": "Ovidiu",
        "output": "M"
    },
    {
        "input": "Cristian-Darius",
        "output": "M"
    },
    {
        "input": "Dalia-ioana",
        "output": "F"
    },
    {
        "input": "Cristian-Andrei",
        "output": "M"
    },
    {
        "input": "Valentin",
        "output": "M"
    },
    {
        "input": "Ioan",
        "output": "M"
    },
    {
        "input": "Ianis-Gabriel",
        "output": "M"
    },
    {
        "input": "RARES-CIPRIAN",
        "output": "M"
    },
    {
        "input": "Alesia",
        "output": "F"
    },
    {
        "input": "Jessica",
        "output": "F"
    },
    {
        "input": "Decebal",
        "output": "M"
    },
    {
        "input": "Rania",
        "output": "F"
    },
    {
        "input": "LaurenÈ›iu",
        "output": "M"
    },
    {
        "input": "RAREÈ˜",
        "output": "M"
    },
    {
        "input": "Alberto",
        "output": "M"
    },
    {
        "input": "Clara",
        "output": "F"
    },
    {
        "input": "Florin",
        "output": "M"
    },
    {
        "input": "Sefora",
        "output": "F"
    },
    {
        "input": "Denisa",
        "output": "M"
    },
    {
        "input": "Isabela-Andreea",
        "output": "F"
    },
    {
        "input": "Ianis-Nicolae",
        "output": "M"
    },
    {
        "input": "Ryan",
        "output": "M"
    },
    {
        "input": "Eveline",
        "output": "M"
    },
    {
        "input": "Alessica",
        "output": "F"
    },
    {
        "input": "AlexandruMihai",
        "output": "M"
    },
    {
        "input": "Makoto",
        "output": "M"
    },
    {
        "input": "Emira",
        "output": "F"
    },
    {
        "input": "Arabella",
        "output": "F"
    },
    {
        "input": "Victoria-Elena",
        "output": "F"
    },
    {
        "input": "Dian",
        "output": "M"
    },
    {
        "input": "Rebecca-Elena",
        "output": "F"
    },
    {
        "input": "Sean",
        "output": "M"
    },
    {
        "input": "AMELIA-SREFANIA",
        "output": "F"
    },
    {
        "input": "Fevronia",
        "output": "F"
    },
    {
        "input": "Isabel",
        "output": "F"
    },
    {
        "input": "Putin",
        "output": "M"
    },
    {
        "input": "Anisia",
        "output": "F"
    },
    {
        "input": "Aris",
        "output": "M"
    },
    {
        "input": "Duman",
        "output": "F"
    },
    {
        "input": "Maya-Ayana",
        "output": "F"
    },
    {
        "input": "Natasha",
        "output": "F"
    },
    {
        "input": "AntoniaMaria",
        "output": "F"
    },
    {
        "input": "Patrik",
        "output": "M"
    },
    {
        "input": "Anronia",
        "output": "F"
    },
    {
        "input": "Sasha",
        "output": "M"
    },
    {
        "input": "Mara",
        "output": "M"
    },
    {
        "input": "Yanis",
        "output": "M"
    },
    {
        "input": "Andreias",
        "output": "M"
    },
    {
        "input": "ENIKO",
        "output": "F"
    },
    {
        "input": "Violeta",
        "output": "F"
    },
    {
        "input": "Andrei-Nicolae",
        "output": "M"
    },
    {
        "input": "Antonia-Nicoleta",
        "output": "F"
    },
    {
        "input": "Damian-Gabriel",
        "output": "M"
    },
    {
        "input": "Eva-Maria",
        "output": "F"
    },
    {
        "input": "Denis-È˜tefan",
        "output": "M"
    },
    {
        "input": "Smaranda",
        "output": "F"
    },
    {
        "input": "Ashanti",
        "output": "F"
    },
    {
        "input": "Renata",
        "output": "F"
    },
    {
        "input": "Octavian",
        "output": "M"
    },
    {
        "input": "Isa",
        "output": "F"
    },
    {
        "input": "Damaris",
        "output": "F"
    },
    {
        "input": "Eliza-Ioana",
        "output": "F"
    },
    {
        "input": "Gabi",
        "output": "M"
    },
    {
        "input": "Arys",
        "output": "M"
    },
    {
        "input": "Vladut",
        "output": "M"
    },
    {
        "input": "Amalia-Georgiana",
        "output": "F"
    },
    {
        "input": "Deian",
        "output": "M"
    },
    {
        "input": "Ilia",
        "output": "F"
    },
    {
        "input": "Edward",
        "output": "M"
    },
    {
        "input": "TEOFANA",
        "output": "F"
    },
    {
        "input": "Elisabetta-Maria",
        "output": "F"
    },
    {
        "input": "Casian-Daniel",
        "output": "M"
    },
    {
        "input": "Daiana",
        "output": "M"
    },
    {
        "input": "Taisia",
        "output": "F"
    },
    {
        "input": "LUCHA",
        "output": "M"
    },
    {
        "input": "LUCHA",
        "output": "F"
    },
    {
        "input": "Annemarie",
        "output": "F"
    },
    {
        "input": "Denis",
        "output": "F"
    },
    {
        "input": "Ela",
        "output": "F"
    },
    {
        "input": "Rahela",
        "output": "F"
    },
    {
        "input": "Ony",
        "output": "M"
    },
    {
        "input": "Mihnea",
        "output": "M"
    },
    {
        "input": "EmÅ‘ke",
        "output": "F"
    },
    {
        "input": "Vasile",
        "output": "M"
    },
    {
        "input": "Virgil",
        "output": "M"
    },
    {
        "input": "Liviu",
        "output": "M"
    },
    {
        "input": "Ian",
        "output": "M"
    },
    {
        "input": "Bumbacu\\'",
        "output": "M"
    },
    {
        "input": "Bumbacu",
        "output": "M"
    },
    {
        "input": "Cox",
        "output": "M"
    },
    {
        "input": "Alexandru-Mihai",
        "output": "M"
    },
    {
        "input": "Amdrei",
        "output": "M"
    },
    {
        "input": "Emma-Nicole",
        "output": "F"
    },
    {
        "input": "Lidia-Ioana",
        "output": "F"
    },
    {
        "input": "Anays",
        "output": "F"
    },
    {
        "input": "Aure",
        "output": "M"
    },
    {
        "input": "Simone",
        "output": "M"
    },
    {
        "input": "Tamas",
        "output": "M"
    },
    {
        "input": "Ana",
        "output": "M"
    },
    {
        "input": "Azaria",
        "output": "F"
    },
    {
        "input": "Philip",
        "output": "M"
    },
    {
        "input": "Amalia-Maria",
        "output": "F"
    },
    {
        "input": "Nadia-È˜tefania",
        "output": "F"
    },
    {
        "input": "Nicolae",
        "output": "M"
    },
    {
        "input": "Luciano",
        "output": "M"
    },
    {
        "input": "Luiza",
        "output": "F"
    },
    {
        "input": "Ania",
        "output": "F"
    },
    {
        "input": "Yannis",
        "output": "M"
    },
    {
        "input": "Gelutu",
        "output": "M"
    },
    {
        "input": "Filip-È˜tefan",
        "output": "M"
    },
    {
        "input": "MATTEO-ANDREI",
        "output": "M"
    },
    {
        "input": "Gheorg",
        "output": "M"
    },
    {
        "input": "Antonia-Maria",
        "output": "F"
    },
    {
        "input": "Dominic",
        "output": "M"
    },
    {
        "input": "Selena",
        "output": "F"
    },
    {
        "input": "Haniel",
        "output": "F"
    },
    {
        "input": "Dani",
        "output": "F"
    },
    {
        "input": "Agnes",
        "output": "F"
    },
    {
        "input": "Raysa",
        "output": "F"
    },
    {
        "input": "ADAM",
        "output": "M"
    },
    {
        "input": "Oana",
        "output": "F"
    },
    {
        "input": "Leia",
        "output": "F"
    },
    {
        "input": "Carina",
        "output": "F"
    },
    {
        "input": "Anca",
        "output": "F"
    },
    {
        "input": "Elvis",
        "output": "M"
    },
    {
        "input": "Ilinca-Maria",
        "output": "F"
    },
    {
        "input": "Ana-Stefania",
        "output": "F"
    },
    {
        "input": "Edy",
        "output": "M"
    },
    {
        "input": "Andreea-Alexandra",
        "output": "F"
    },
    {
        "input": "Evelin",
        "output": "F"
    },
    {
        "input": "Nicole",
        "output": "F"
    },
    {
        "input": "Timeea",
        "output": "F"
    },
    {
        "input": "Sofrone",
        "output": "M"
    },
    {
        "input": "Matteo",
        "output": "F"
    },
    {
        "input": "Oprea",
        "output": "M"
    },
    {
        "input": "PiÈ™cu",
        "output": "F"
    },
    {
        "input": "NATI",
        "output": "F"
    },
    {
        "input": "Tiffany",
        "output": "F"
    },
    {
        "input": "Sara-Maria",
        "output": "F"
    },
    {
        "input": "KasianaBriana",
        "output": "F"
    },
    {
        "input": "Eva-Mihaela",
        "output": "F"
    },
    {
        "input": "Ianis",
        "output": "F"
    },
    {
        "input": "Azaleea",
        "output": "F"
    },
    {
        "input": "Marei",
        "output": "M"
    },
    {
        "input": "Elisabeth",
        "output": "F"
    },
    {
        "input": "Natalis",
        "output": "F"
    },
    {
        "input": "Adonis",
        "output": "M"
    },
    {
        "input": "Carla-Maria",
        "output": "F"
    },
    {
        "input": "Xenia",
        "output": "F"
    },
    {
        "input": "Isabella",
        "output": "F"
    },
    {
        "input": "Noah",
        "output": "M"
    },
    {
        "input": "Andrei",
        "output": "M"
    },
    {
        "input": "Ingrid-Maria",
        "output": "F"
    },
    {
        "input": "Silviu",
        "output": "M"
    },
    {
        "input": "Delia",
        "output": "F"
    },
    {
        "input": "Adriana",
        "output": "F"
    },
    {
        "input": "Abel",
        "output": "M"
    },
    {
        "input": "Esme",
        "output": "F"
    },
    {
        "input": "Leonte",
        "output": "M"
    },
    {
        "input": "Nick",
        "output": "M"
    },
    {
        "input": "Laura",
        "output": "F"
    },
    {
        "input": "Mamalunelu",
        "output": "F"
    },
    {
        "input": "Remus",
        "output": "M"
    },
    {
        "input": "Gigel",
        "output": "M"
    },
    {
        "input": "Dorinash",
        "output": "M"
    },
    {
        "input": "Scuipici",
        "output": "M"
    },
    {
        "input": "Onur",
        "output": "M"
    },
    {
        "input": "Dana",
        "output": "F"
    },
    {
        "input": "Gigel",
        "output": "F"
    },
    {
        "input": "Didi",
        "output": "F"
    },
    {
        "input": "Caius",
        "output": "M"
    },
    {
        "input": "DragoÈ™",
        "output": "M"
    },
    {
        "input": "Theodor-Nicolae",
        "output": "M"
    },
    {
        "input": "Ionut",
        "output": "M"
    },
    {
        "input": "Luana",
        "output": "F"
    },
    {
        "input": "Ysabela",
        "output": "F"
    },
    {
        "input": "Yasmina",
        "output": "F"
    },
    {
        "input": "Emanuel",
        "output": "M"
    },
    {
        "input": "Amza",
        "output": "M"
    },
    {
        "input": "Filofteia",
        "output": "F"
    },
    {
        "input": "Isadora",
        "output": "F"
    },
    {
        "input": "BebeN",
        "output": "M"
    },
    {
        "input": "RareÈ™-Petru",
        "output": "M"
    },
    {
        "input": "Riccardo",
        "output": "M"
    },
    {
        "input": "Minodora",
        "output": "F"
    },
    {
        "input": "Minodora",
        "output": "O"
    },
    {
        "input": "Minodora",
        "output": "M"
    },
    {
        "input": "Ai de viata mea",
        "output": "M"
    },
    {
        "input": "Nina",
        "output": "F"
    },
    {
        "input": "Anja",
        "output": "F"
    },
    {
        "input": "Julius",
        "output": "M"
    },
    {
        "input": "Felice",
        "output": "M"
    },
    {
        "input": "Andrwi",
        "output": "M"
    },
    {
        "input": "Doina",
        "output": "F"
    },
    {
        "input": "Georgi",
        "output": "F"
    },
    {
        "input": "Alin",
        "output": "M"
    },
    {
        "input": "Teo",
        "output": "M"
    },
    {
        "input": "Steli",
        "output": "M"
    },
    {
        "input": "Elisa",
        "output": "F"
    },
    {
        "input": "Anndra",
        "output": "F"
    },
    {
        "input": "DÄƒnuÈ›",
        "output": "M"
    },
    {
        "input": "Ionel",
        "output": "M"
    },
    {
        "input": "Radu.    ",
        "output": "M"
    },
    {
        "input": "Giorgica",
        "output": "M"
    },
    {
        "input": "Cotiso",
        "output": "M"
    },
    {
        "input": "Annais",
        "output": "F"
    },
    {
        "input": "Igor",
        "output": "M"
    },
    {
        "input": "Leon",
        "output": "M"
    },
    {
        "input": "Ami",
        "output": "F"
    },
    {
        "input": "Capy",
        "output": "M"
    },
    {
        "input": "Octav",
        "output": "M"
    },
    {
        "input": "Adi",
        "output": "M"
    },
    {
        "input": "Pisica",
        "output": "F"
    },
    {
        "input": "Pauli",
        "output": "M"
    },
    {
        "input": "Blondie",
        "output": "F"
    },
    {
        "input": "Marcus",
        "output": "M"
    },
    {
        "input": "Aida",
        "output": "F"
    },
    {
        "input": "Raymond",
        "output": "M"
    }
];
